/* 
 * File:   tmr1.h
 * Author: Bernardo Lopes
 *
 * Created on August 18, 2017, 9:58 PM
 */

#ifndef TMR1_H
#define	TMR1_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "all.h"

extern int tmr1time;
    
void tmr1_init(void);
void __attribute__((__interrupt__, no_auto_psv)) _T1Interrupt(void);

#ifdef	__cplusplus
}
#endif

#endif	/* TMR1_H */

