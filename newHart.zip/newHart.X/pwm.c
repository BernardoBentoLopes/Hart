
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include "pwm.h"


void pwm_init(int value, double duty){
    
     /*~~~~~~~~~~~ Pin Configuration ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    TRISBbits.TRISB10 = 0; // Pin 23 as output 
    
    /*~~~~~~~~~~~ PWM2 Configuration ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    PTPER = FOSC/(value*8); 
    IOCON2bits.PENH      = 1;  /* PWM2H is controlled by PWM module */
    IOCON2bits.PMOD      = 0;  /* Select Independent Output PWM mode */
    PDC2 = PTPER*duty;         /* Initial Duty cycle */ 
    DTR2    = 0;               /* Deadtime setting */
    ALTDTR2 = 0;               /* Deadtime setting */
    PHASE2 = 0;                /* */
    
    PTCONbits.PTEN       = 1; /* Enable the PWM Module */  
}

void pwm_set_dutycycle(double duty){
    PDC2 = PTPER*duty;         /* Initial Duty cycle */ 
}
