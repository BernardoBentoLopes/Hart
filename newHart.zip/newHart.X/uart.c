#include "all.h"

//is data available in RX buffer?
unsigned char UART1RXRdy(void){
    return U1STAbits.URXDA;
}
//get a byte from UART
unsigned char UART1RX(void){
    while(U1STAbits.URXDA == 0);
    return U1RXREG;
}
//add byte to buffer, pause if full
//uses PIC UART FIFO buffer
void UART1TX(char c){
    if(U1STAbits.UTXEN ==0)U1STAbits.UTXEN = 1; //enable UART TX
    while(U1STAbits.UTXBF == 1);                //if buffer is full, wait
    U1TXREG = c;
}
//Initialize the terminal UART
void InitializeUART1(void){
   /*~~~~~~~~~~~ Pin Configuration ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    
    TRISBbits.TRISB9 = 0; // Pin 18 as output
    TRISBbits.TRISB8 = 1; // Pin 17 as input
    /****************************************************************************
     * Set the PPS
     ***************************************************************************/
    __builtin_write_OSCCONL(OSCCON & 0xbf); // unlock PPS

    RPINR18bits.U1RXR = 0x0028;   //RB8->UART1:U1RX;
    RPOR3bits.RP41R = 0x0001;   //RB9->UART1:U1TX;

    __builtin_write_OSCCONL(OSCCON | 0x40); // lock   PPS

    /*~~~~~~~~~~~ UART1 Config ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    U1BRG = 85;                                 //baudrate=115200 when fp=80Mhz -> UxBRG=(fp/4*baudrate) - 1 (UART adenda pag. 12 Equation 3.3)
    U1MODE = 0;                                 //clear mode register
  
    U1MODEbits.BRGH = 1;                        //use high percison baud generator
    U1STA = 0;                                  //clear status register
    U1MODEbits.UARTEN = 1;                      //enable the UART RX
    IFS0bits.U1RXIF = 0;                        //clear the receive flag
}
