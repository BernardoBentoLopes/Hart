/* 
 * File:   exint.h
 * Author: Bernardo Lopes
 *
 * Created on August 19, 2017, 3:25 PM
 */

#ifndef EXINT_H
#define	EXINT_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include "all.h"
    extern float currentRPM;
    void exint_int(void);

    
    
    
#ifdef	__cplusplus
}
#endif

#endif	/* EXINT_H */

