/* 
 * File:   PWM.h
 * Author: Bernardo Lopes
 *
 * Created on August 18, 2017, 7:02 PM
 */
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

#ifndef PWM_H
#define	PWM_H

#ifdef	__cplusplus
extern "C" {
#endif

#define FOSC 120000000

void pwm_init(int value, double duty);

void pwm_set_dutycycle(double duty);



#ifdef	__cplusplus
}
#endif

#endif	/* PWM_H */
