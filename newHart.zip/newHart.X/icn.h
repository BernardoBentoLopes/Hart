/* 
 * File:   icn.h
 * Author: Bernardo Lopes
 *
 * Created on August 18, 2017, 8:03 PM
 */

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

#ifndef ICN_H
#define	ICN_H

#ifdef	__cplusplus
extern "C" {
#endif

#define lidar_encoder_1 PORTBbits.RB4
#define lidar_encoder_2 PORTBbits.RB9
    
extern int encoderCount;
extern int currentAngle;
extern uint32_t oldTime;
extern uint32_t newTime;    
void configure_CN(void);

void __attribute__ ((__interrupt__)) _CNInterrupt(void);
    
    
    


#ifdef	__cplusplus
}
#endif

#endif	/* ICN_H */

