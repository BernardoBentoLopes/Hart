#include "all.h"


void tmr1_init(void){
    
    T1CONbits.TON = 0; // Disable Timer
    T1CONbits.TCS = 0; // Select internal instruction cycle clock - 1.8425Mhz
    T1CONbits.TGATE = 0; // Disable Gated Timer mode
    T1CONbits.TCKPS = 0b01; // Select 1:8 Prescaler
    TMR1 = 0x00; // Clear timer register
    PR1 = 0x4; // Load the period value - ~ 2us -- supostamente deveria ser 0x5 para 1us 
    IPC0bits.T1IP = 0x01; // Set Timer 1 Interrupt Priority Level
    IFS0bits.T1IF = 0; // Clear Timer 1 Interrupt Flag
    IEC0bits.T1IE = 1; // Enable Timer1 interrupt
    T1CONbits.TON = 1; // Start Timer
    
   
    
}

int tmr1time = 0;

void __attribute__((__interrupt__, no_auto_psv)) _T1Interrupt(void)
{
/* Interrupt Service Routine code goes here */
    LATBbits.LATB6 = ~LATBbits.LATB6 ;
    tmr1time = tmr1time + 2;
 
    IFS0bits.T1IF = 0; //Clear Timer1 interrupt flag
}