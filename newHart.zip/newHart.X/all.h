/* 
 * File:   all.h
 * Author: Bernardo Lopes
 *
 * Created on August 18, 2017, 8:08 PM
 */

#ifndef ALL_H
#define	ALL_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "icn.h"
#include "pwm.h"
#include "tmr1.h"
#include "uart.h"
#include "exint.h"

#ifdef	__cplusplus
}
#endif

#endif	/* ALL_H */

