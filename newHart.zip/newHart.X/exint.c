#include "all.h"

void exint_int(void){
    /*~~~~~~~~~~~ Pin Configuration ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    
    TRISAbits.TRISA4 = 1; // Pin 12 as input
    ANSELAbits.ANSA4 = 0;
    
    /****************************************************************************
     * Set the PPS
     **********************************************************************/
    __builtin_write_OSCCONL(OSCCON & 0xbf); // unlock PPS

    RPINR1bits.INT2R = 0x0014;   //RA4->EXT_INT:INT2;

    __builtin_write_OSCCONL(OSCCON | 0x40); // lock   PPS*****
            
    /*~~~~~~~~~~~ Interrupt 2 Configuration ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    IPC7bits.INT2IP = 5; //    Priority: 5
    IFS1bits.INT2IF = 0; // Clears the interrupt flag for INT2
    INTCON2bits.INT2EP = 0;// Sets the edge detect of the external interrupt to positive edge.
    IEC1bits.INT2IE = 1; //  Clears the interrupt enable for INT2
     
}


int gearRatio = 298;
int ppr = 5;

float currentRPM = 0;
void __attribute__ ( ( interrupt, no_auto_psv ) ) _INT2Interrupt(void)
{
    //***User Area Begin->code: External Interrupt 0***
    LATBbits.LATB6 = ~LATBbits.LATB6 ;
    /*~~~~~~~~~~~ RPM  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    currentRPM = 60/((float)tmr1time*0.000001*ppr*gearRatio);
    UART1TX((char)currentRPM);
    tmr1time = 0; // Reseting Timer
    
    //***User Area End->code: External Interrupt 0***
     IFS1bits.INT2IF = 0; //Interrupt Flag clear
}