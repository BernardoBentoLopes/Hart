/* 
 * File:   uart.h
 * Author: Bernardo Lopes
 *
 * Created on August 21, 2017, 12:16 PM
 */

#ifndef UART_H
#define	UART_H

#ifdef	__cplusplus
extern "C" {
#endif
#include "all.h"
    
    unsigned char UART1RXRdy(void);
    unsigned char UART1RX(void);
    void UART1TX(char c);
    void InitializeUART1(void);



#ifdef	__cplusplus
}
#endif

#endif	/* UART_H */

